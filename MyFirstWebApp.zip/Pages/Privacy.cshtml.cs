﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFirstWebApp.Pages;

public class PrivacyModel : PageModel
{
    public void OnGet()
    {
    }
}

